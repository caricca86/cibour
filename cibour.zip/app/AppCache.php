<?php

use Symfony\Bundle\FrameworkBundle\HttpCache\HttpCache;

class FrontCache extends HttpCache
{
}
